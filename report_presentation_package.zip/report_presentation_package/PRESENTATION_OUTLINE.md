# Five-Slide Presentation Outline

Target length: about 5–6 minutes. The technical depth belongs in the speech,
not dense slide text. Use the exact figure assignments and layouts below.

## Slide 1 — Cover

**Title:** VAE vs. DDPM for Image Generation on Fashion-MNIST

**Subtitle:** Image quality versus computational efficiency

Include team names and course. No result table or architecture diagram.

**Figure:** none. A clean cover is stronger than a decorative sample grid.

## Slide 2 — Question and Fair Comparison

**Headline:** What do we gain—and pay for—when moving from a VAE to diffusion?

- Same Fashion-MNIST data: 60k train, 10k test.
- VAE: 32-D latent space, one decoder pass.
- DDPM: 100 reverse steps, time-conditioned U-Net + EMA.
- Same 5,000-sample evaluation and 91.34%-accurate feature classifier.

**Figures and layout:**

- Left half: `figures/main/vae_latent_interpolation.png`.
- Right half: `figures/main/ddpm_denoising_trajectory.png`.
- Put a small label above each: “one latent interpolation / one decoder pass”
  and “noise to image / 100 reverse steps.”
- Put the four setup facts in a narrow strip along the bottom.

These are real outputs, so they explain the mechanisms more credibly than a
generic architecture diagram.

## Slide 3 — Quality and Diversity Results

**Headline:** DDPM generated more recognizable and better-balanced samples.

- Classifier-feature FID: 7.66 vs. 51.12.
- Confidence >= 0.8: 65.6% vs. 41.0%.
- Class entropy: 0.991 vs. 0.931; both cover all 10 classes.

**Figures and layout:**

- Top 55% of slide: `figures/main/real_vae_ddpm_comparison.png`, full width.
- Bottom-left: `figures/main/class_distribution_comparison.png`.
- Bottom-right: three large callouts: FID `51.12 -> 7.66`, confidence >= 0.8
  `41.0% -> 65.6%`, entropy `0.931 -> 0.991`.

Do not add the separate FID and KID bar plots to this slide; they repeat the
callouts and make the sample comparison too small.

## Slide 4 — The Cost of Better Samples

**Headline:** DDPM quality came with a large compute penalty.

- Training: 4.76 min vs. 0.37 min (~12.8x slower).
- Sampling: 8.02 vs. 0.0075 ms/image (~1,068x slower).
- Peak GPU allocation: 6.28 GB vs. 0.56 GB (~11.2x).
- Parameters: 5.22M vs. 1.70M (~3.1x).

**Figures and layout:**

- Left: `figures/main/training_time_comparison.png`.
- Right: `figures/main/sampling_time_comparison.png`.
- Bottom callout: `DDPM: ~12.8x training time, ~1,068x sampling latency,
  ~11.2x peak allocation`.

Keep the memory and parameter values as small text beneath the callout; do not
add more charts.

## Slide 5 — Takeaway and Limits

**Headline:** Choose based on the deployment constraint.

- DDPM when sample quality and balanced coverage matter most.
- VAE when latency, memory, and rapid generation matter most.
- Evidence is specific to one seed and non-parameter-matched implementations.
- Next step: repeat seeds and test fewer DDPM sampling steps.

End with one sentence: **“In our experiment, diffusion bought quality with
compute; the VAE bought speed with blurrier samples.”**

**Figure:** none. Use a two-column decision card instead:

- left card, “Choose VAE”: low latency, low memory, fast iteration;
- right card, “Choose DDPM”: stronger feature match, recognition, and balance.

Add a small footer: “Limits: one seed; unmatched capacity; classifier-based
evaluation.” This makes the final decision and its qualification readable.

## Backup figures for questions (not part of the five slides)

- `figures/appendix/vae_nearest_neighbors.png` and
  `ddpm_nearest_neighbors.png` for memorization questions.
- `figures/appendix/vae_lowest_confidence_samples.png` and
  `ddpm_lowest_confidence_samples.png` for failure cases.
- `figures/appendix/vae_total_loss.png` and
  `ddpm_noise_prediction_loss.png` for convergence questions.
- `figures/appendix/classifier_confusion_matrix.png` when discussing evaluator
  reliability and its 91.34% test accuracy.
