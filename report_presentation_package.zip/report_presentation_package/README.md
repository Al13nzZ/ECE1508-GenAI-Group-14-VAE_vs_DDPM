# Report and Presentation Package

This package contains the evidence worth using in the final report and a
five-slide presentation. It deliberately excludes checkpoints, generated
tensor files, and redundant plots.

## Recommended main-report figures

1. `figures/main/real_vae_ddpm_comparison.png` — primary qualitative result.
2. `figures/main/vae_latent_interpolation.png` and
   `figures/main/ddpm_denoising_trajectory.png` — generation mechanisms.
3. `figures/main/class_distribution_comparison.png` — diversity evidence;
   move this from the draft appendix into the quantitative-results section.
4. `figures/main/training_time_comparison.png` and
   `figures/main/sampling_time_comparison.png` — efficiency evidence. Put them
   together as one two-panel figure after the paragraph about compute cost.

The FID/KID values are already clearer in the main table than in separate bar
charts, so the individual FID/KID plots are kept as optional slide assets.

## Appendix-only figures

- training curves: stability/convergence evidence;
- nearest-neighbor grids: memorization screen;
- lowest-confidence samples: transparent failure-case analysis;
- classifier confusion matrix: evaluator limitation/context.

## Key numbers

- Evaluation classifier accuracy: 91.34%.
- DDPM classifier-feature FID: 7.66; VAE: 51.12.
- DDPM classifier-feature KID: 0.326; VAE: 1.874.
- Confidence >= 0.8: DDPM 65.6%; VAE 41.0%.
- Class entropy: DDPM 0.991; VAE 0.931; both cover 10/10 classes.
- Training: DDPM 4.76 min; VAE 0.37 min.
- Batched sampling: DDPM 8.02 ms/image; VAE 0.0075 ms/image.
- Peak allocated GPU memory: DDPM 6275 MB; VAE 558 MB.
- Parameters: DDPM 5.22M; VAE 1.70M.

Use the exact CSV values for tables; rounded values above are for prose and
slides.

