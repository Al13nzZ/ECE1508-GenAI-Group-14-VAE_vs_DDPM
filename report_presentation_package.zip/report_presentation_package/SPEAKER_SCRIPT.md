# Speaker Script — Detailed 5–6 Minute Version

## Slide 1 — Cover (20–25 seconds)

“We compared two generative models on Fashion-MNIST: a convolutional VAE and a
denoising diffusion model. Our question was practical: under one shared
experiment, how much sample quality does diffusion add, and what does that cost
in training, memory, and generation time?”

## Slide 2 — Question and Method (50–60 seconds)

“Both models used the same 60,000 training images and were evaluated against
the same 10,000-image test distribution. The VAE compresses each
image into a 32-dimensional Gaussian latent space and generates through one
decoder pass. The DDPM uses a time-conditioned U-Net and starts from noise,
then performs 100 reverse denoising steps. We generated 5,000 samples from each
model. For a shared evaluator, we trained a Fashion-MNIST classifier with 91.34
percent test accuracy and used its predictions and 128-dimensional features.
That gave us recognizability, class balance, and classifier-feature FID and
KID. These are Fashion-MNIST-specific metrics, not standard ImageNet FID and
KID. FID compares feature means and covariances under a Gaussian approximation,
while KID is a kernel two-sample statistic, so agreement between them is more
convincing than either score alone.”

## Slide 3 — Quality and Diversity (65–75 seconds)

“The top figure uses equal numbers of real, VAE, and DDPM images. The visual
difference is clear: the VAE learns the correct overall clothing
shapes, but its samples are softer and less distinct. The DDPM produces sharper
edges and more recognizable structure. The quantitative results agree. DDPM
reduced classifier-feature FID from 51.12 to 7.66 and KID from 1.874 to 0.326.
The percentage of samples classified with at least 0.8 confidence increased
from 41.0 to 65.6 percent. Both models produced all ten predicted classes, but
coverage alone hides imbalance. The VAE overproduced several classes, while
the DDPM distribution was much closer to uniform, with normalized entropy
0.991 instead of 0.931. Entropy equals one for a perfectly uniform ten-class
distribution. It measures balance across predicted classes, not diversity
within a class, so we interpret it together with the image grid rather than as
a complete diversity score.”

## Slide 4 — Computational Cost (60–70 seconds)

“That quality improvement was expensive, as the two plots show. VAE training took 0.37 minutes; DDPM
training took 4.76 minutes, about 13 times longer. Batched VAE sampling took
0.0075 milliseconds per image, while the 100-step DDPM took 8.02 milliseconds,
about 1,068 times slower in this implementation. Peak allocated GPU
memory rose from 558 megabytes to 6.28 gigabytes, and the DDPM had about three
times as many parameters. The parameter gap cannot explain a thousand-fold
sampling difference. The main cause is structural: a VAE uses one decoder pass,
while this DDPM performs 100 sequential network evaluations. The timing values
come from the same RTX 5070 Ti and large-batch mixed-precision run, so they are
valid for our within-system comparison but are not hardware-independent latency
claims.”

## Slide 5 — Conclusion (45–55 seconds)

“So there is no winner on every dimension. In our implementation, DDPM is the
better choice when generation quality and balanced class coverage are the main
requirements. The VAE is much more attractive when latency, memory, or rapid
iteration matters. We should not treat this as a universal ranking because we
used one random seed, class-based metrics depend on a 91.34-percent-accurate
evaluator, and the models were not parameter matched. Our nearest-neighbor
screen found no strong evidence of direct memorization, but it is not proof of
absence. The strongest
next experiments are repeated seeds, matched-capacity models, and faster DDPM
samplers with fewer reverse steps. Our main takeaway is simple: diffusion
bought quality with compute, while the VAE bought speed with blurrier
samples.”

## Short answers for likely questions

**Why not standard FID?** Fashion-MNIST is 28x28 grayscale and poorly matched
to an ImageNet Inception network, so we used features from a Fashion-MNIST
classifier and label the metric accordingly.

**Is the comparison perfectly fair?** It uses the same data and evaluator, but
the architectures are not parameter matched and only one seed was run.

**Did either model memorize the training set?** The nearest-neighbor screen did
not show strong evidence of direct memorization, but it cannot prove that
memorization is absent.

**Why is DDPM sampling slower?** It requires 100 sequential denoising network
passes; the VAE requires one decoder pass.
